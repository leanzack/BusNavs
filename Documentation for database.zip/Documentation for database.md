﻿3rd Exam – IT 26 /L Subject code: 

![](Aspose.Words.1d77153e-8bcc-43f8-9b30-2dcc2c500fba.001.png) ![](Aspose.Words.1d77153e-8bcc-43f8-9b30-2dcc2c500fba.002.png)

Busnavs: Navigation and Ticketing 

LEANDRO P. PANINSORO 

May 2024 

A- DASHBOARD DESIGN  

![](Aspose.Words.1d77153e-8bcc-43f8-9b30-2dcc2c500fba.003.jpeg)

B- LOG-IN AND SIGN-UP DESIGN  

![](Aspose.Words.1d77153e-8bcc-43f8-9b30-2dcc2c500fba.004.png)

![](Aspose.Words.1d77153e-8bcc-43f8-9b30-2dcc2c500fba.005.png)

![](Aspose.Words.1d77153e-8bcc-43f8-9b30-2dcc2c500fba.006.png)

![](Aspose.Words.1d77153e-8bcc-43f8-9b30-2dcc2c500fba.007.png)

C- CRUD DESIGN - Create 

Create route with fare add as a button. 

![](Aspose.Words.1d77153e-8bcc-43f8-9b30-2dcc2c500fba.008.jpeg)

Plus, sign button to add the route. 

![](Aspose.Words.1d77153e-8bcc-43f8-9b30-2dcc2c500fba.009.png)

The first option is the input dialog for the route name.

![](Aspose.Words.1d77153e-8bcc-43f8-9b30-2dcc2c500fba.010.png)

The second option is an input dialog that takes a fare with a decimal value. 

![](Aspose.Words.1d77153e-8bcc-43f8-9b30-2dcc2c500fba.011.png)

![](Aspose.Words.1d77153e-8bcc-43f8-9b30-2dcc2c500fba.012.png)

![](Aspose.Words.1d77153e-8bcc-43f8-9b30-2dcc2c500fba.013.jpeg)

CRUD DESIGN – Delete 

Red Button with “delete” label. 

![](Aspose.Words.1d77153e-8bcc-43f8-9b30-2dcc2c500fba.014.png)

![](Aspose.Words.1d77153e-8bcc-43f8-9b30-2dcc2c500fba.015.png)

![](Aspose.Words.1d77153e-8bcc-43f8-9b30-2dcc2c500fba.016.png)

CRUD DESIGN – Update 

Updating the value of fare (UM route with fare 300 to 23) 

![](Aspose.Words.1d77153e-8bcc-43f8-9b30-2dcc2c500fba.017.png)

![](Aspose.Words.1d77153e-8bcc-43f8-9b30-2dcc2c500fba.018.png)

![](Aspose.Words.1d77153e-8bcc-43f8-9b30-2dcc2c500fba.019.png)

Value of fare after update 

![](Aspose.Words.1d77153e-8bcc-43f8-9b30-2dcc2c500fba.020.png)

CRUD DESIGN – Read 

Clicking each button to select route and read the database. 

![](Aspose.Words.1d77153e-8bcc-43f8-9b30-2dcc2c500fba.021.png)

![](Aspose.Words.1d77153e-8bcc-43f8-9b30-2dcc2c500fba.022.png)

D - DATABASE DESIGN (DATA DICTIONARY) 

Driver Table 



|Field Names |Data Type |Length |
| - | - | - |
|PK – driver\_id |Integer |3 |
|Driver\_name |Text |50 |

Passenger Table 



|Field Names |Data Type |Length |
| - | - | - |
|PK – passenger\_id |Integer  |3 |
|Passenger\_name |Text |50 |

Routes Table 



|Field Names |Data Type |Length |
| - | - | - |
|PK – route\_id |Integer  |3 |
|FK – Route\_name |Text |255 |
|FK – fare |Decimal |10,2 |

SelectedRoutes Table 



|Field Names |Data Type |Length |
| - | - | - |
|FK – Driver\_name |Text |50 |
|FK – Selected\_route |Text |255 |
|fare |Decimal |10,2 |

Ticket Table 



|Field Names |Data Type |Length |
| - | - | - |
|PK – Ticket\_id |Integer – Auto Increment |3 |
|FK – Passenger\_name |Text |50 |
|FK – Driver\_name |Text |50 |
|FK – Route\_name |Text |255 |
|FK – fare |Decimal |10, 2 |

E – ENTITY RELATIONSHIP DIAGRAM 

![](Aspose.Words.1d77153e-8bcc-43f8-9b30-2dcc2c500fba.023.jpeg)
**Busnavs: Navigation and Ticketing** 12 
